import Stopwatch from "./stopwatch.jsx";

function App() {

  return(<Stopwatch />);
  
  
}

export default App
